from .string import string

__all__ = ["string"]